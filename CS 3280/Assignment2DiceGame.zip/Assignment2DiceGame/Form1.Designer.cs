﻿namespace Assignment2DiceGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdRoll = new System.Windows.Forms.Button();
            this.cmdReset = new System.Windows.Forms.Button();
            this.pbDiceImg = new System.Windows.Forms.PictureBox();
            this.lblGuess = new System.Windows.Forms.Label();
            this.txtUserGuess = new System.Windows.Forms.TextBox();
            this.gbGameInfo = new System.Windows.Forms.GroupBox();
            this.lblTimesLost = new System.Windows.Forms.Label();
            this.lblTimesWon = new System.Windows.Forms.Label();
            this.lblPlayed = new System.Windows.Forms.Label();
            this.lblError = new System.Windows.Forms.Label();
            this.lblFace1 = new System.Windows.Forms.Label();
            this.lblFace2 = new System.Windows.Forms.Label();
            this.lblFace3 = new System.Windows.Forms.Label();
            this.lblFace4 = new System.Windows.Forms.Label();
            this.lblFace5 = new System.Windows.Forms.Label();
            this.lblFace6 = new System.Windows.Forms.Label();
            this.rtbGameResults = new System.Windows.Forms.RichTextBox();
            this.lblFreq1 = new System.Windows.Forms.Label();
            this.lblFreq2 = new System.Windows.Forms.Label();
            this.lblFreq3 = new System.Windows.Forms.Label();
            this.lblFreq4 = new System.Windows.Forms.Label();
            this.lblFreq5 = new System.Windows.Forms.Label();
            this.lblFreq6 = new System.Windows.Forms.Label();
            this.lblPerc1 = new System.Windows.Forms.Label();
            this.lblPerc6 = new System.Windows.Forms.Label();
            this.lblPerc2 = new System.Windows.Forms.Label();
            this.lblPerc3 = new System.Windows.Forms.Label();
            this.lblPerc4 = new System.Windows.Forms.Label();
            this.lblPerc5 = new System.Windows.Forms.Label();
            this.lblGuess1 = new System.Windows.Forms.Label();
            this.lblGuess6 = new System.Windows.Forms.Label();
            this.lblGuess5 = new System.Windows.Forms.Label();
            this.lblGuess3 = new System.Windows.Forms.Label();
            this.lblGuess4 = new System.Windows.Forms.Label();
            this.lblGuess2 = new System.Windows.Forms.Label();
            this.lblAmountPlayed = new System.Windows.Forms.Label();
            this.lblAmountWon = new System.Windows.Forms.Label();
            this.lblAmountLost = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbDiceImg)).BeginInit();
            this.gbGameInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdRoll
            // 
            this.cmdRoll.Location = new System.Drawing.Point(191, 244);
            this.cmdRoll.Name = "cmdRoll";
            this.cmdRoll.Size = new System.Drawing.Size(75, 23);
            this.cmdRoll.TabIndex = 0;
            this.cmdRoll.Text = "Roll";
            this.cmdRoll.UseVisualStyleBackColor = true;
            this.cmdRoll.Click += new System.EventHandler(this.cmdRoll_Click);
            // 
            // cmdReset
            // 
            this.cmdReset.Location = new System.Drawing.Point(191, 312);
            this.cmdReset.Name = "cmdReset";
            this.cmdReset.Size = new System.Drawing.Size(75, 23);
            this.cmdReset.TabIndex = 1;
            this.cmdReset.Text = "Reset";
            this.cmdReset.UseVisualStyleBackColor = true;
            this.cmdReset.Click += new System.EventHandler(this.cmdReset_Click);
            // 
            // pbDiceImg
            // 
            this.pbDiceImg.Location = new System.Drawing.Point(43, 226);
            this.pbDiceImg.Name = "pbDiceImg";
            this.pbDiceImg.Size = new System.Drawing.Size(119, 109);
            this.pbDiceImg.TabIndex = 3;
            this.pbDiceImg.TabStop = false;
            // 
            // lblGuess
            // 
            this.lblGuess.AutoSize = true;
            this.lblGuess.Location = new System.Drawing.Point(12, 178);
            this.lblGuess.Name = "lblGuess";
            this.lblGuess.Size = new System.Drawing.Size(155, 17);
            this.lblGuess.TabIndex = 4;
            this.lblGuess.Text = "Enter your guess (1-6):";
            // 
            // txtUserGuess
            // 
            this.txtUserGuess.Location = new System.Drawing.Point(191, 178);
            this.txtUserGuess.MaxLength = 1;
            this.txtUserGuess.Name = "txtUserGuess";
            this.txtUserGuess.Size = new System.Drawing.Size(42, 22);
            this.txtUserGuess.TabIndex = 5;
            // 
            // gbGameInfo
            // 
            this.gbGameInfo.Controls.Add(this.lblAmountLost);
            this.gbGameInfo.Controls.Add(this.lblTimesLost);
            this.gbGameInfo.Controls.Add(this.lblAmountWon);
            this.gbGameInfo.Controls.Add(this.lblTimesWon);
            this.gbGameInfo.Controls.Add(this.lblAmountPlayed);
            this.gbGameInfo.Controls.Add(this.lblPlayed);
            this.gbGameInfo.Location = new System.Drawing.Point(15, 12);
            this.gbGameInfo.Name = "gbGameInfo";
            this.gbGameInfo.Size = new System.Drawing.Size(251, 149);
            this.gbGameInfo.TabIndex = 6;
            this.gbGameInfo.TabStop = false;
            this.gbGameInfo.Text = "Game Info";
            // 
            // lblTimesLost
            // 
            this.lblTimesLost.AutoSize = true;
            this.lblTimesLost.Location = new System.Drawing.Point(6, 109);
            this.lblTimesLost.Name = "lblTimesLost";
            this.lblTimesLost.Size = new System.Drawing.Size(151, 17);
            this.lblTimesLost.TabIndex = 2;
            this.lblTimesLost.Text = "Number of Times Lost:";
            // 
            // lblTimesWon
            // 
            this.lblTimesWon.AutoSize = true;
            this.lblTimesWon.Location = new System.Drawing.Point(4, 74);
            this.lblTimesWon.Name = "lblTimesWon";
            this.lblTimesWon.Size = new System.Drawing.Size(153, 17);
            this.lblTimesWon.TabIndex = 1;
            this.lblTimesWon.Text = "Number of Times Won:";
            // 
            // lblPlayed
            // 
            this.lblPlayed.AutoSize = true;
            this.lblPlayed.Location = new System.Drawing.Point(6, 36);
            this.lblPlayed.Name = "lblPlayed";
            this.lblPlayed.Size = new System.Drawing.Size(167, 17);
            this.lblPlayed.TabIndex = 0;
            this.lblPlayed.Text = "Number of Times Played:";
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.Location = new System.Drawing.Point(240, 182);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(0, 17);
            this.lblError.TabIndex = 7;
            // 
            // lblFace1
            // 
            this.lblFace1.AutoSize = true;
            this.lblFace1.BackColor = System.Drawing.SystemColors.Window;
            this.lblFace1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFace1.Location = new System.Drawing.Point(19, 372);
            this.lblFace1.Name = "lblFace1";
            this.lblFace1.Size = new System.Drawing.Size(18, 20);
            this.lblFace1.TabIndex = 8;
            this.lblFace1.Text = "1";
            // 
            // lblFace2
            // 
            this.lblFace2.AutoSize = true;
            this.lblFace2.BackColor = System.Drawing.SystemColors.Window;
            this.lblFace2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFace2.Location = new System.Drawing.Point(19, 399);
            this.lblFace2.Name = "lblFace2";
            this.lblFace2.Size = new System.Drawing.Size(18, 20);
            this.lblFace2.TabIndex = 9;
            this.lblFace2.Text = "2";
            // 
            // lblFace3
            // 
            this.lblFace3.AutoSize = true;
            this.lblFace3.BackColor = System.Drawing.SystemColors.Window;
            this.lblFace3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFace3.Location = new System.Drawing.Point(19, 428);
            this.lblFace3.Name = "lblFace3";
            this.lblFace3.Size = new System.Drawing.Size(18, 20);
            this.lblFace3.TabIndex = 10;
            this.lblFace3.Text = "3";
            // 
            // lblFace4
            // 
            this.lblFace4.AutoSize = true;
            this.lblFace4.BackColor = System.Drawing.SystemColors.Window;
            this.lblFace4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFace4.Location = new System.Drawing.Point(19, 456);
            this.lblFace4.Name = "lblFace4";
            this.lblFace4.Size = new System.Drawing.Size(18, 20);
            this.lblFace4.TabIndex = 11;
            this.lblFace4.Text = "4";
            // 
            // lblFace5
            // 
            this.lblFace5.AutoSize = true;
            this.lblFace5.BackColor = System.Drawing.SystemColors.Window;
            this.lblFace5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFace5.Location = new System.Drawing.Point(19, 483);
            this.lblFace5.Name = "lblFace5";
            this.lblFace5.Size = new System.Drawing.Size(18, 20);
            this.lblFace5.TabIndex = 12;
            this.lblFace5.Text = "5";
            // 
            // lblFace6
            // 
            this.lblFace6.AutoSize = true;
            this.lblFace6.BackColor = System.Drawing.SystemColors.Window;
            this.lblFace6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFace6.Location = new System.Drawing.Point(19, 509);
            this.lblFace6.Name = "lblFace6";
            this.lblFace6.Size = new System.Drawing.Size(18, 20);
            this.lblFace6.TabIndex = 13;
            this.lblFace6.Text = "6";
            // 
            // rtbGameResults
            // 
            this.rtbGameResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbGameResults.Location = new System.Drawing.Point(12, 344);
            this.rtbGameResults.Name = "rtbGameResults";
            this.rtbGameResults.Size = new System.Drawing.Size(670, 212);
            this.rtbGameResults.TabIndex = 2;
            this.rtbGameResults.Text = "FACE           FREQUENCY          PERCENT         NUMBER OF TIMES GUESSED \n\n";
            // 
            // lblFreq1
            // 
            this.lblFreq1.AutoSize = true;
            this.lblFreq1.BackColor = System.Drawing.SystemColors.Window;
            this.lblFreq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFreq1.Location = new System.Drawing.Point(141, 372);
            this.lblFreq1.Name = "lblFreq1";
            this.lblFreq1.Size = new System.Drawing.Size(18, 20);
            this.lblFreq1.TabIndex = 14;
            this.lblFreq1.Text = "0";
            // 
            // lblFreq2
            // 
            this.lblFreq2.AutoSize = true;
            this.lblFreq2.BackColor = System.Drawing.SystemColors.Window;
            this.lblFreq2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFreq2.Location = new System.Drawing.Point(140, 399);
            this.lblFreq2.Name = "lblFreq2";
            this.lblFreq2.Size = new System.Drawing.Size(18, 20);
            this.lblFreq2.TabIndex = 15;
            this.lblFreq2.Text = "0";
            // 
            // lblFreq3
            // 
            this.lblFreq3.AutoSize = true;
            this.lblFreq3.BackColor = System.Drawing.SystemColors.Window;
            this.lblFreq3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFreq3.Location = new System.Drawing.Point(141, 428);
            this.lblFreq3.Name = "lblFreq3";
            this.lblFreq3.Size = new System.Drawing.Size(18, 20);
            this.lblFreq3.TabIndex = 16;
            this.lblFreq3.Text = "0";
            // 
            // lblFreq4
            // 
            this.lblFreq4.AutoSize = true;
            this.lblFreq4.BackColor = System.Drawing.SystemColors.Window;
            this.lblFreq4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFreq4.Location = new System.Drawing.Point(141, 456);
            this.lblFreq4.Name = "lblFreq4";
            this.lblFreq4.Size = new System.Drawing.Size(18, 20);
            this.lblFreq4.TabIndex = 17;
            this.lblFreq4.Text = "0";
            // 
            // lblFreq5
            // 
            this.lblFreq5.AutoSize = true;
            this.lblFreq5.BackColor = System.Drawing.SystemColors.Window;
            this.lblFreq5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFreq5.Location = new System.Drawing.Point(141, 483);
            this.lblFreq5.Name = "lblFreq5";
            this.lblFreq5.Size = new System.Drawing.Size(18, 20);
            this.lblFreq5.TabIndex = 18;
            this.lblFreq5.Text = "0";
            // 
            // lblFreq6
            // 
            this.lblFreq6.AutoSize = true;
            this.lblFreq6.BackColor = System.Drawing.SystemColors.Window;
            this.lblFreq6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFreq6.Location = new System.Drawing.Point(140, 509);
            this.lblFreq6.Name = "lblFreq6";
            this.lblFreq6.Size = new System.Drawing.Size(18, 20);
            this.lblFreq6.TabIndex = 19;
            this.lblFreq6.Text = "0";
            // 
            // lblPerc1
            // 
            this.lblPerc1.AutoSize = true;
            this.lblPerc1.BackColor = System.Drawing.SystemColors.Window;
            this.lblPerc1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPerc1.Location = new System.Drawing.Point(273, 372);
            this.lblPerc1.Name = "lblPerc1";
            this.lblPerc1.Size = new System.Drawing.Size(55, 20);
            this.lblPerc1.TabIndex = 20;
            this.lblPerc1.Text = "0.00%";
            // 
            // lblPerc6
            // 
            this.lblPerc6.AutoSize = true;
            this.lblPerc6.BackColor = System.Drawing.SystemColors.Window;
            this.lblPerc6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPerc6.Location = new System.Drawing.Point(273, 509);
            this.lblPerc6.Name = "lblPerc6";
            this.lblPerc6.Size = new System.Drawing.Size(55, 20);
            this.lblPerc6.TabIndex = 21;
            this.lblPerc6.Text = "0.00%";
            // 
            // lblPerc2
            // 
            this.lblPerc2.AutoSize = true;
            this.lblPerc2.BackColor = System.Drawing.SystemColors.Window;
            this.lblPerc2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPerc2.Location = new System.Drawing.Point(273, 399);
            this.lblPerc2.Name = "lblPerc2";
            this.lblPerc2.Size = new System.Drawing.Size(55, 20);
            this.lblPerc2.TabIndex = 22;
            this.lblPerc2.Text = "0.00%";
            // 
            // lblPerc3
            // 
            this.lblPerc3.AutoSize = true;
            this.lblPerc3.BackColor = System.Drawing.SystemColors.Window;
            this.lblPerc3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPerc3.Location = new System.Drawing.Point(273, 428);
            this.lblPerc3.Name = "lblPerc3";
            this.lblPerc3.Size = new System.Drawing.Size(55, 20);
            this.lblPerc3.TabIndex = 23;
            this.lblPerc3.Text = "0.00%";
            // 
            // lblPerc4
            // 
            this.lblPerc4.AutoSize = true;
            this.lblPerc4.BackColor = System.Drawing.SystemColors.Window;
            this.lblPerc4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPerc4.Location = new System.Drawing.Point(273, 456);
            this.lblPerc4.Name = "lblPerc4";
            this.lblPerc4.Size = new System.Drawing.Size(55, 20);
            this.lblPerc4.TabIndex = 24;
            this.lblPerc4.Text = "0.00%";
            // 
            // lblPerc5
            // 
            this.lblPerc5.AutoSize = true;
            this.lblPerc5.BackColor = System.Drawing.SystemColors.Window;
            this.lblPerc5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPerc5.Location = new System.Drawing.Point(273, 483);
            this.lblPerc5.Name = "lblPerc5";
            this.lblPerc5.Size = new System.Drawing.Size(55, 20);
            this.lblPerc5.TabIndex = 25;
            this.lblPerc5.Text = "0.00%";
            // 
            // lblGuess1
            // 
            this.lblGuess1.AutoSize = true;
            this.lblGuess1.BackColor = System.Drawing.SystemColors.Window;
            this.lblGuess1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuess1.Location = new System.Drawing.Point(507, 372);
            this.lblGuess1.Name = "lblGuess1";
            this.lblGuess1.Size = new System.Drawing.Size(18, 20);
            this.lblGuess1.TabIndex = 3;
            this.lblGuess1.Text = "0";
            // 
            // lblGuess6
            // 
            this.lblGuess6.AutoSize = true;
            this.lblGuess6.BackColor = System.Drawing.SystemColors.Window;
            this.lblGuess6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuess6.Location = new System.Drawing.Point(507, 509);
            this.lblGuess6.Name = "lblGuess6";
            this.lblGuess6.Size = new System.Drawing.Size(18, 20);
            this.lblGuess6.TabIndex = 26;
            this.lblGuess6.Text = "0";
            // 
            // lblGuess5
            // 
            this.lblGuess5.AutoSize = true;
            this.lblGuess5.BackColor = System.Drawing.SystemColors.Window;
            this.lblGuess5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuess5.Location = new System.Drawing.Point(507, 483);
            this.lblGuess5.Name = "lblGuess5";
            this.lblGuess5.Size = new System.Drawing.Size(18, 20);
            this.lblGuess5.TabIndex = 27;
            this.lblGuess5.Text = "0";
            // 
            // lblGuess3
            // 
            this.lblGuess3.AutoSize = true;
            this.lblGuess3.BackColor = System.Drawing.SystemColors.Window;
            this.lblGuess3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuess3.Location = new System.Drawing.Point(507, 428);
            this.lblGuess3.Name = "lblGuess3";
            this.lblGuess3.Size = new System.Drawing.Size(18, 20);
            this.lblGuess3.TabIndex = 28;
            this.lblGuess3.Text = "0";
            // 
            // lblGuess4
            // 
            this.lblGuess4.AutoSize = true;
            this.lblGuess4.BackColor = System.Drawing.SystemColors.Window;
            this.lblGuess4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuess4.Location = new System.Drawing.Point(507, 456);
            this.lblGuess4.Name = "lblGuess4";
            this.lblGuess4.Size = new System.Drawing.Size(18, 20);
            this.lblGuess4.TabIndex = 29;
            this.lblGuess4.Text = "0";
            // 
            // lblGuess2
            // 
            this.lblGuess2.AutoSize = true;
            this.lblGuess2.BackColor = System.Drawing.SystemColors.Window;
            this.lblGuess2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuess2.Location = new System.Drawing.Point(507, 399);
            this.lblGuess2.Name = "lblGuess2";
            this.lblGuess2.Size = new System.Drawing.Size(18, 20);
            this.lblGuess2.TabIndex = 30;
            this.lblGuess2.Text = "0";
            // 
            // lblAmountPlayed
            // 
            this.lblAmountPlayed.AutoSize = true;
            this.lblAmountPlayed.Location = new System.Drawing.Point(199, 36);
            this.lblAmountPlayed.Name = "lblAmountPlayed";
            this.lblAmountPlayed.Size = new System.Drawing.Size(16, 17);
            this.lblAmountPlayed.TabIndex = 31;
            this.lblAmountPlayed.Text = "0";
            // 
            // lblAmountWon
            // 
            this.lblAmountWon.AutoSize = true;
            this.lblAmountWon.Location = new System.Drawing.Point(199, 74);
            this.lblAmountWon.Name = "lblAmountWon";
            this.lblAmountWon.Size = new System.Drawing.Size(16, 17);
            this.lblAmountWon.TabIndex = 32;
            this.lblAmountWon.Text = "0";
            // 
            // lblAmountLost
            // 
            this.lblAmountLost.AutoSize = true;
            this.lblAmountLost.Location = new System.Drawing.Point(199, 109);
            this.lblAmountLost.Name = "lblAmountLost";
            this.lblAmountLost.Size = new System.Drawing.Size(16, 17);
            this.lblAmountLost.TabIndex = 33;
            this.lblAmountLost.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(750, 560);
            this.Controls.Add(this.lblGuess2);
            this.Controls.Add(this.lblGuess4);
            this.Controls.Add(this.lblGuess3);
            this.Controls.Add(this.lblGuess5);
            this.Controls.Add(this.lblGuess6);
            this.Controls.Add(this.lblGuess1);
            this.Controls.Add(this.lblPerc5);
            this.Controls.Add(this.lblPerc4);
            this.Controls.Add(this.lblPerc3);
            this.Controls.Add(this.lblPerc2);
            this.Controls.Add(this.lblPerc6);
            this.Controls.Add(this.lblPerc1);
            this.Controls.Add(this.lblFreq6);
            this.Controls.Add(this.lblFreq5);
            this.Controls.Add(this.lblFreq4);
            this.Controls.Add(this.lblFreq3);
            this.Controls.Add(this.lblFreq2);
            this.Controls.Add(this.lblFreq1);
            this.Controls.Add(this.lblFace6);
            this.Controls.Add(this.lblFace5);
            this.Controls.Add(this.lblFace4);
            this.Controls.Add(this.lblFace3);
            this.Controls.Add(this.lblFace2);
            this.Controls.Add(this.lblFace1);
            this.Controls.Add(this.lblError);
            this.Controls.Add(this.gbGameInfo);
            this.Controls.Add(this.txtUserGuess);
            this.Controls.Add(this.lblGuess);
            this.Controls.Add(this.pbDiceImg);
            this.Controls.Add(this.rtbGameResults);
            this.Controls.Add(this.cmdReset);
            this.Controls.Add(this.cmdRoll);
            this.Name = "Form1";
            this.Text = "Dice Game";
            ((System.ComponentModel.ISupportInitialize)(this.pbDiceImg)).EndInit();
            this.gbGameInfo.ResumeLayout(false);
            this.gbGameInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdRoll;
        private System.Windows.Forms.Button cmdReset;
        private System.Windows.Forms.PictureBox pbDiceImg;
        private System.Windows.Forms.Label lblGuess;
        private System.Windows.Forms.TextBox txtUserGuess;
        private System.Windows.Forms.GroupBox gbGameInfo;
        private System.Windows.Forms.Label lblTimesLost;
        private System.Windows.Forms.Label lblTimesWon;
        private System.Windows.Forms.Label lblPlayed;
        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.Label lblFace1;
        private System.Windows.Forms.Label lblFace2;
        private System.Windows.Forms.Label lblFace3;
        private System.Windows.Forms.Label lblFace4;
        private System.Windows.Forms.Label lblFace5;
        private System.Windows.Forms.Label lblFace6;
        private System.Windows.Forms.RichTextBox rtbGameResults;
        private System.Windows.Forms.Label lblFreq1;
        private System.Windows.Forms.Label lblFreq2;
        private System.Windows.Forms.Label lblFreq3;
        private System.Windows.Forms.Label lblFreq4;
        private System.Windows.Forms.Label lblFreq5;
        private System.Windows.Forms.Label lblFreq6;
        private System.Windows.Forms.Label lblPerc1;
        private System.Windows.Forms.Label lblPerc6;
        private System.Windows.Forms.Label lblPerc2;
        private System.Windows.Forms.Label lblPerc3;
        private System.Windows.Forms.Label lblPerc4;
        private System.Windows.Forms.Label lblPerc5;
        private System.Windows.Forms.Label lblGuess1;
        private System.Windows.Forms.Label lblGuess6;
        private System.Windows.Forms.Label lblGuess5;
        private System.Windows.Forms.Label lblGuess3;
        private System.Windows.Forms.Label lblGuess4;
        private System.Windows.Forms.Label lblGuess2;
        private System.Windows.Forms.Label lblAmountLost;
        private System.Windows.Forms.Label lblAmountWon;
        private System.Windows.Forms.Label lblAmountPlayed;
    }
}

