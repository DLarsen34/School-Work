﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Assignment2DiceGame
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// variables to keep track of games are played, how many games are won, and how many games are lost.
        /// </summary>
        private int timesPlayed = 0;
        private int timesWon = 0;
        private int timesLost = 0;

        /// <summary>
        /// variables to keep track of the frequency at which each face is rolled.
        /// </summary>
        private int frequency1 = 0;
        private int frequency2 = 0;
        private int frequency3 = 0;
        private int frequency4 = 0;
        private int frequency5 = 0;
        private int frequency6 = 0;

        /// <summary>
        /// variables to keep track of how many times the user guesses a certain number.
        /// </summary>
        private int guess1 = 0;
        private int guess2 = 0;
        private int guess3 = 0;
        private int guess4 = 0;
        private int guess5 = 0;
        private int guess6 = 0;

        /// <summary>
        /// This is what the users guess is stored in once it's converted from a string in the text box to an int
        /// </summary>
        private int iUserGuess;

        /// <summary>
        /// variables to keep track of the percentage that a certain number is rolled
        /// </summary>
        private float percent1;
        private float percent2;
        private float percent3;
        private float percent4;
        private float percent5;
        private float percent6;


        public Form1()
        {
            InitializeComponent();

            //Which face the dice defaults to before the game is used and once the game is reset.
            pbDiceImg.Image = Image.FromFile("die" + 1.ToString() + ".gif");
        }

        /// <summary>
        /// Function that is activated when the user clicks the roll button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdRoll_Click(object sender, EventArgs e)
        {
            Int32.TryParse(txtUserGuess.Text, out iUserGuess);
            
            //checks to make sure user enters valid input. Wont roll unless input in valid, and will output error if not-valid.
            if (txtUserGuess.Text == "")
            {
                lblError.Text = "Guess must be 1-6";
            }
            else if (iUserGuess > 6)
            {
                lblError.Text = "Guess must be 1-6";
            }
            else
            {
                lblError.Text = "";
                Random diceRoll = new Random(); //Random Generator
                int random = diceRoll.Next(1, 7); //stores the random number that is used to compare against user guess.
                for (int i = 0; i < 7; i++)
                {
                    pbDiceImg.Image = Image.FromFile("die" + diceRoll.Next(1, 7).ToString() + ".gif"); //Simulates the dice roll.
                    pbDiceImg.Refresh();
                    Thread.Sleep(300);
                }
                pbDiceImg.Image = Image.FromFile("die" + random.ToString() + ".gif"); //Random number that the die lands on.
                if (iUserGuess == random) // checks to see if the users guess was correct or incorrect and increment the appropriate variable
                {
                    ++timesWon;
                }
                else
                {
                    ++timesLost;
                }
                ++timesPlayed; //increment everytime roll is selected and input is valid.
                switch (random) //switch statment used to increment the correct frequency depending on which number is rolled.
                {
                    case 1:
                        frequency1++;
                        break;
                    case 2:
                        frequency2++;
                        break;
                    case 3:
                        frequency3++;
                        break;
                    case 4:
                        frequency4++;
                        break;
                    case 5:
                        frequency5++;
                        break;
                    case 6:
                        frequency6++;
                        break;
                }
                switch (iUserGuess) //switch statement used to increment the correct variable depending on what the user guessed would be rolled.
                {
                    case 1:
                        guess1++;
                        break;
                    case 2:
                        guess2++;
                        break;
                    case 3:
                        guess3++;
                        break;
                    case 4:
                        guess4++;
                        break;
                    case 5:
                        guess5++;
                        break;
                    case 6:
                        guess6++;
                        break;
                }
            }
            //Calculates the percentage that each number has been rolled.
            percent1 = ((float)frequency1 / timesPlayed) * 100;
            percent2 = ((float)frequency2 / timesPlayed) * 100;
            percent3 = ((float)frequency3 / timesPlayed) * 100;
            percent4 = ((float)frequency4 / timesPlayed) * 100;
            percent5 = ((float)frequency5/ timesPlayed) * 100;
            percent6 = ((float)frequency6 / timesPlayed) * 100;
            
            //Displays all the information to the user and updates after each roll
            lblAmountPlayed.Text = timesPlayed.ToString();
            lblAmountWon.Text = timesWon.ToString();
            lblAmountLost.Text = timesLost.ToString();
            lblFreq1.Text = frequency1.ToString();
            lblFreq2.Text = frequency2.ToString();
            lblFreq3.Text = frequency3.ToString();
            lblFreq4.Text = frequency4.ToString();
            lblFreq5.Text = frequency5.ToString();
            lblFreq6.Text = frequency6.ToString();
            lblGuess1.Text = guess1.ToString();
            lblGuess2.Text = guess2.ToString();
            lblGuess3.Text = guess3.ToString();
            lblGuess4.Text = guess4.ToString();
            lblGuess5.Text = guess5.ToString();
            lblGuess6.Text = guess6.ToString();
            lblPerc1.Text = String.Format("{0:f2}", percent1) + "%";
            lblPerc2.Text = String.Format("{0:f2}", percent2) + "%";
            lblPerc3.Text = String.Format("{0:f2}", percent3) + "%";
            lblPerc4.Text = String.Format("{0:f2}", percent4) + "%";
            lblPerc5.Text = String.Format("{0:f2}", percent5) + "%";
            lblPerc6.Text = String.Format("{0:f2}", percent6) + "%";
        }

        /// <summary>
        /// Function that is called when the user clicks the reset button. Sets that game back to it's original state.
        /// Where everything is equal to 0. The board will look exactly like it did before the user clicked roll for the first time.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdReset_Click(object sender, EventArgs e)
        {
            timesPlayed = 0;
            timesWon = 0;
            timesLost = 0;
            frequency1 = 0;
            frequency2 = 0;
            frequency3 = 0;
            frequency4 = 0;
            frequency5 = 0;
            frequency6 = 0;
            guess1 = 0;
            guess2 = 0;
            guess3 = 0;
            guess4 = 0;
            guess5 = 0;
            guess6 = 0;
            percent1 = 0;
            percent2 = 0;
            percent3 = 0;
            percent4 = 0;
            percent5 = 0;
            percent6 = 0;
            lblAmountPlayed.Text = timesPlayed.ToString();
            lblAmountWon.Text = timesWon.ToString();
            lblAmountLost.Text = timesLost.ToString();
            lblFreq1.Text = frequency1.ToString();
            lblFreq2.Text = frequency2.ToString();
            lblFreq3.Text = frequency3.ToString();
            lblFreq4.Text = frequency4.ToString();
            lblFreq5.Text = frequency5.ToString();
            lblFreq6.Text = frequency6.ToString();
            lblGuess1.Text = guess1.ToString();
            lblGuess2.Text = guess2.ToString();
            lblGuess3.Text = guess3.ToString();
            lblGuess4.Text = guess4.ToString();
            lblGuess5.Text = guess5.ToString();
            lblGuess6.Text = guess6.ToString();
            lblPerc1.Text = String.Format("{0:f2}", percent1) + "%";
            lblPerc2.Text = String.Format("{0:f2}", percent2) + "%";
            lblPerc3.Text = String.Format("{0:f2}", percent3) + "%";
            lblPerc4.Text = String.Format("{0:f2}", percent4) + "%";
            lblPerc5.Text = String.Format("{0:f2}", percent5) + "%";
            lblPerc6.Text = String.Format("{0:f2}", percent6) + "%";
            txtUserGuess.Text = "";
            lblError.Text = "";
            pbDiceImg.Image = Image.FromFile("die" + 1.ToString() + ".gif");
        }
    }
}
