public class Tile 
{
	public boolean matches(Tile other)
	{
		if(this == other || other == null)
			return false;
		if(getClass() == other.getClass())
			return true;
		return false;
	}
}
