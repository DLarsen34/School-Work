public class CharacterTile extends Tile
{
	protected char symbol;
	
	public CharacterTile(char symbol)
	{
		this.symbol = symbol;
	}
	
	public boolean matches(Tile other)
	{
		return super.matches(other) && symbol == ((CharacterTile)other).symbol;
	}
	
	public String toString()
	{
		if(symbol == 'N')
			return "North Wind";
		else if(symbol == 'E')
			return "East Wind";
		else if(symbol == 'W')
			return "West Wind";
		else if(symbol == 'S')
			return "South Wind";
		else if(symbol == 'C')
			return "Red Dragon";
		else if(symbol == 'F')
			return "Green Dragon";
		else
			return "Character " + symbol;
	}
}
